import {LitElement, html} from "lit-element";

export class Registro extends LitElement{

    constructor(){
        super();
        this.username = '';
        this.password = '';
        this.email = '';
    }

    static get properties(){
        return{
            username:{
                type: String
            },
            password:{
                type: String
            },
            email:{
                type: String
            }
        }
    }

    setUsername(e){
        this.username = e.target.value;
    }

    setPassword(e){
        this.password = e.target.value;
    }

    setEmail(e){
        this.email = e.target.value;
    }

    submitForm(e){
        e.preventDefault();
        console.log('Username:', this.username);
        console.log('Password:', this.password);
        console.log('Email:', this.email);
    }

    render(){
        return html`
            <form @submit=${this.submitForm}>
                <label>
                    Username:
                    <input type="text" @input=${this.setUsername} />
                </label>
                <br />
                <label>
                    Password:
                    <input type="password" @input=${this.setPassword} />
                </label>
                <br />
                <label>
                    Email:
                    <input type="email" @input=${this.setEmail} />
                </label>
                <br />
                <button type="submit">Submit</button>
            </form>
        `;
    }
}

customElements.define('registro', Registro);
