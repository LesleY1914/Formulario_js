import {LitElement, html} from "lit-element";

export class MyElement extends LitElement{

    constructor(){
        super();
        this.saludo ='Mundo';
    }
    static get properties(){
        return{
            saludo:{
                type: String
            }
        }
    }



    setValue(nombre){
        this.saludo = nombre;
    }


    render(){
        return html`
        <h1>Hola ${this.saludo} </h1>
        <button @click= ${()=> this.setValue('Lesley Camargo')}> Cambio saludo</button>
        <button>Registro</button>
        <button @click= >login</button>`
    }
}




customElements.define('my-element', MyElement);