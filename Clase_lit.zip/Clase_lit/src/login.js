import {LitElement, html} from "lit-element";

export class Login extends LitElement{

    constructor(){
        super();
        this.username = '';
        this.password = '';
    }

    static get properties(){
        return{
            username:{
                type: String
            },
            password:{
                type: String
            }
        }
    }

    setUsername(e){
        this.username = e.target.value;
    }

    setPassword(e){
        this.password = e.target.value;
    }

    submitForm(e){
        e.preventDefault();
        console.log('Username:', this.username);
        console.log('Password:', this.password);
    }

    render(){
        return html`
            <form @submit=${this.submitForm}>
                <label>   
                    Username:
                    <input type="text" @input=${this.setUsername} />
                </label>
                <br />
                <label>
                    Password:
                    <input type="password" @input=${this.setPassword} />
                </label>
                <br />
                <button type="submit">Submit</button>
            </form>
        `;
    }
}

customElements.define('login', Login);
